import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/providers/settings_provider.dart';
import 'core/services/chinese_segmenter_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Workaround: 修复 macOS 模拟器键盘状态 bug
  // Flutter 框架 bug：模拟器在处理 Meta (Command) 键时会重复触发 KeyDown
  // 忽略这个断言错误，不影响实际功能
  FlutterError.onError = (details) {
    if (details.exceptionAsString().contains('physical key is already pressed')) {
      debugPrint('⚠️ 忽略键盘重复按下错误 (Flutter framework bug)');
      return;
    }
    FlutterError.presentError(details);
  };

  // 初始化中文分词器（jieba）
  await ChineseSegmenterService.init();

  // 初始化 SettingsService
  final settingsService = SettingsService();
  await settingsService.initialize();

  // NOTE: SessionManager、SessionRepository、MessageRepository 均由 Riverpod
  // 按需懒初始化，不在这里手动创建实例，避免产生双重实例和幽灵会话。
  // 首次启动时，若没有任何会话，UI 会在 SessionListPage 的空状态下
  // 引导用户通过「+」按钮手动创建第一个会话并选择模型。

  runApp(
    ProviderScope(
      overrides: [
        settingsServiceProvider.overrideWithValue(settingsService),
      ],
      child: const App(),
    ),
  );
}
