import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../storage/database.dart';
import '../storage/database_connection.dart';

/// 全局数据库 Provider
final databaseProvider = Provider<AppDatabase>((ref) {
  return database;
});