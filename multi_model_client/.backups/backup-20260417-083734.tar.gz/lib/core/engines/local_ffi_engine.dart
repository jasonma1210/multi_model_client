import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:llama_cpp_dart/llama_cpp_dart.dart';
import 'package:path_provider/path_provider.dart';

import '../models/model_entry.dart';
import 'model_inference_engine.dart';

/// 本地 FFI 推理引擎
/// 使用 llama_cpp_dart 直接加载 GGUF 模型，无需 Ollama 服务
///
/// 支持平台：
/// - macOS: Metal 加速 (Apple Silicon)
/// - iOS: Metal 加速
/// - Android: Vulkan/OpenCL 加速
/// - Windows: CUDA/CPU
/// - Linux: CUDA/CPU
class LocalFFIEngine {
  static final LocalFFIEngine _instance = LocalFFIEngine._();
  static LocalFFIEngine get instance => _instance;

  LocalFFIEngine._();

  // 当前加载的模型
  Llama? _llama;
  String? _currentModelPath;

  // 状态
  bool get isInitialized => _llama != null;
  String? get currentModelPath => _currentModelPath;

  // ════════════════════════════════════════════════════════════════════════
  //  平台检测
  // ════════════════════════════════════════════════════════════════════════

  /// 检测当前平台支持的加速后端
  static AccelerationBackend detectAccelerationBackend() {
    if (Platform.isMacOS || Platform.isIOS) {
      return AccelerationBackend.metal;
    } else if (Platform.isWindows || Platform.isLinux) {
      return AccelerationBackend.cpu; // 简化处理
    } else if (Platform.isAndroid) {
      return AccelerationBackend.vulkan;
    }
    return AccelerationBackend.cpu;
  }

  /// 获取 llama.cpp 库路径
  static String getLibraryPath() {
    if (Platform.isMacOS || Platform.isIOS) {
      return 'libllama.dylib';
    } else if (Platform.isWindows) {
      return 'libllama.dll';
    } else {
      return 'libllama.so';
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  //  模型加载
  // ════════════════════════════════════════════════════════════════════════

  /// 加载 GGUF 模型
  /// [modelPath] 模型文件路径（可以是本地路径或应用内路径）
  /// [params] 模型参数（可选）
  Future<void> loadModel({
    required String modelPath,
    LocalModelParams? params,
  }) async {
    // 如果已有模型，先卸载
    await dispose();

    // 记录当前模型路径
    _currentModelPath = modelPath;

    // 设置 llama.cpp 库路径
    final libraryPath = await _getLibraryFullPath();
    Llama.libraryPath = libraryPath;

    // 创建 Llama 实例（同步方式，用于简单场景）
    _llama = Llama(modelPath);

    debugPrint('LocalFFIEngine: Model loaded from $modelPath');
    debugPrint('LocalFFIEngine: Backend: ${detectAccelerationBackend().name}');
  }

  /// 获取库文件的完整路径
  Future<String> _getLibraryFullPath() async {
    final libraryPath = getLibraryPath();

    // 尝试从多个位置查找库文件
    final searchPaths = <String>[];

    // 1. 应用文档目录（用户下载的模型所在目录）
    final docDir = await getApplicationDocumentsDirectory();
    searchPaths.add('${docDir.path}/llama_cpp/$libraryPath');

    // 2. 应用支持目录（存放 bundled 库）
    final supportDir = await getApplicationSupportDirectory();
    searchPaths.add('${supportDir.path}/llama_cpp/$libraryPath');

    // 3. 当前工作目录
    searchPaths.add('./llama_cpp/$libraryPath');

    // 4. 系统路径（用户自己编译的库）
    searchPaths.add(libraryPath);

    for (final path in searchPaths) {
      if (File(path).existsSync()) {
        debugPrint('LocalFFIEngine: Found library at $path');
        return path;
      }
    }

    // 如果都没找到，返回默认路径
    debugPrint('LocalFFIEngine: Library not found, using default path');
    return libraryPath;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  文本生成（同步方式）
  // ════════════════════════════════════════════════════════════════════════

  /// 阻塞式生成（等待完整结果）
  Future<String> generate(
    List<ChatMessage> messages, {
    ChatOptions? options,
  }) async {
    _ensureInitialized();

    final prompt = _buildPrompt(messages);
    _llama!.setPrompt(prompt);

    final buffer = StringBuffer();
    while (true) {
      final (token, done) = _llama!.getNext();
      buffer.write(token);
      if (done) break;
    }

    return buffer.toString();
  }

  /// 流式生成（实时返回 token）
  Stream<String> generateStream(
    List<ChatMessage> messages, {
    ChatOptions? options,
  }) async* {
    _ensureInitialized();

    final prompt = _buildPrompt(messages);
    _llama!.setPrompt(prompt);

    while (true) {
      final (token, done) = _llama!.getNext();
      yield token;
      if (done) break;
    }
  }

  /// 构建 prompt 字符串
  /// 将消息列表转换为纯文本 prompt
  String _buildPrompt(List<ChatMessage> messages) {
    final buffer = StringBuffer();

    for (final message in messages) {
      switch (message.role) {
        case 'system':
          buffer.writeln('System: ${message.content}');
          break;
        case 'user':
          buffer.writeln('User: ${message.content}');
          break;
        case 'assistant':
          buffer.writeln('Assistant: ${message.content}');
          break;
        default:
          buffer.writeln(message.content);
      }
    }

    buffer.write('Assistant:');
    return buffer.toString();
  }

  // ════════════════════════════════════════════════════════════════════════
  //  模型管理
  // ════════════════════════════════════════════════════════════════════════

  /// 检查模型是否已加载
  bool isModelLoaded(String modelPath) {
    return _llama != null && _currentModelPath == modelPath;
  }

  /// 卸载当前模型，释放内存
  Future<void> unloadModel() async {
    if (_llama != null) {
      _llama!.dispose();
      _llama = null;
      _currentModelPath = null;
      debugPrint('LocalFFIEngine: Model unloaded');
    }
  }

  /// 释放所有资源
  Future<void> dispose() async {
    await unloadModel();
  }

  // ════════════════════════════════════════════════════════════════════════
  //  辅助方法
  // ════════════════════════════════════════════════════════════════════════

  void _ensureInitialized() {
    if (_llama == null) {
      throw LocalFFIException(
        'LocalFFIEngine is not initialized. '
        'Please load a model first using loadModel().',
      );
    }
  }
}

// ════════════════════════════════════════════════════════════════════════
//  异常类
// ════════════════════════════════════════════════════════════════════════

class LocalFFIException implements Exception {
  final String message;
  LocalFFIException(this.message);

  @override
  String toString() => 'LocalFFIException: $message';
}

// ════════════════════════════════════════════════════════════════════════
//  模型信息
// ════════════════════════════════════════════════════════════════════════

class ModelInfo {
  final String path;
  final String backend;
  final bool loaded;

  ModelInfo({
    required this.path,
    required this.backend,
    required this.loaded,
  });
}

// ════════════════════════════════════════════════════════════════════════
//  加速后端枚举
// ════════════════════════════════════════════════════════════════════════

enum AccelerationBackend {
  metal,  // Apple Metal (macOS/iOS)
  cuda,    // NVIDIA CUDA (Windows/Linux)
  vulkan,  // Vulkan (Android)
  cpu,     // CPU only
}
