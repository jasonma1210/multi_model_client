import 'dart:ffi';
import 'dart:io';
import 'package:ffi/ffi.dart';
import 'package:flutter/foundation.dart';

// llama.cpp FFI bindings
class LlamaCppBindings {
  final DynamicLibrary _lib;

  LlamaCppBindings(this._lib);

  // Load model
  Pointer<Void> llama_load_model_from_file(
    Pointer<Utf8> model_path,
    Pointer<Void> params,
  ) {
    return _lib.lookupFunction<
        Pointer<Void> Function(Pointer<Utf8>, Pointer<Void>),
        Pointer<Void> Function(Pointer<Utf8>, Pointer<Void>)>(
      'llama_load_model_from_file',
    )(model_path, params);
  }

  // Free model
  void llama_free_model(Pointer<Void> model) {
    _lib.lookupFunction<
        Void Function(Pointer<Void>),
        void Function(Pointer<Void>)>(
      'llama_free_model',
    )(model);
  }

  // Create context
  Pointer<Void> llama_new_context_with_model(
    Pointer<Void> model,
    Pointer<Void> params,
  ) {
    return _lib.lookupFunction<
        Pointer<Void> Function(Pointer<Void>, Pointer<Void>),
        Pointer<Void> Function(Pointer<Void>, Pointer<Void>)>(
      'llama_new_context_with_model',
    )(model, params);
  }

  // Free context
  void llama_free(Pointer<Void> ctx) {
    _lib.lookupFunction<
        Void Function(Pointer<Void>),
        void Function(Pointer<Void>)>(
      'llama_free',
    )(ctx);
  }

  // Tokenize
  int llama_tokenize(
    Pointer<Void> model,
    Pointer<Utf8> text,
    int text_len,
    Pointer<Int32> tokens,
    int n_max_tokens,
    int add_bos,
  ) {
    return _lib.lookupFunction<
        Int32 Function(Pointer<Void>, Pointer<Utf8>, Int32, Pointer<Int32>, Int32, Int32),
        int Function(Pointer<Void>, Pointer<Utf8>, int, Pointer<Int32>, int, int)>(
      'llama_tokenize',
    )(model, text, text_len, tokens, n_max_tokens, add_bos);
  }

  // Eval
  int llama_eval(
    Pointer<Void> ctx,
    Pointer<Int32> tokens,
    int n_tokens,
    int n_past,
    int n_threads,
  ) {
    return _lib.lookupFunction<
        Int32 Function(Pointer<Void>, Pointer<Int32>, Int32, Int32, Int32),
        int Function(Pointer<Void>, Pointer<Int32>, int, int, int)>(
      'llama_eval',
    )(ctx, tokens, n_tokens, n_past, n_threads);
  }

  // Get logits
  Pointer<Float> llama_get_logits(Pointer<Void> ctx) {
    return _lib.lookupFunction<
        Pointer<Float> Function(Pointer<Void>),
        Pointer<Float> Function(Pointer<Void>)>(
      'llama_get_logits',
    )(ctx);
  }

  // Sample token
  int llama_sample_token(
    Pointer<Void> ctx,
    Pointer<Int32> candidates,
    int n_candidates,
    double temp,
    double top_p,
    int top_k,
  ) {
    return _lib.lookupFunction<
        Int32 Function(Pointer<Void>, Pointer<Int32>, Int32, Float, Float, Int32),
        int Function(Pointer<Void>, Pointer<Int32>, int, double, double, int)>(
      'llama_sample_token',
    )(ctx, candidates, n_candidates, temp, top_p, top_k);
  }

  // Token to string
  int llama_token_to_str(
    Pointer<Void> model,
    int token,
    Pointer<Utf8> buf,
    int length,
  ) {
    return _lib.lookupFunction<
        Int32 Function(Pointer<Void>, Int32, Pointer<Utf8>, Int32),
        int Function(Pointer<Void>, int, Pointer<Utf8>, int)>(
      'llama_token_to_str',
    )(model, token, buf, length);
  }
}

class LlamaModel {
  final String modelPath;
  final int contextSize;
  final int threads;
  final double temperature;
  final double topP;
  final int topK;
  final int gpuLayers;           // GPU层数（Metal/CUDA）
  final bool enableMetal;        // 启用Metal加速
  final bool enableCuda;         // 启用CUDA加速
  final int batchSize;           // 批处理大小

  LlamaModel({
    required this.modelPath,
    this.contextSize = 2048,
    this.threads = 4,
    this.temperature = 0.8,
    this.topP = 0.95,
    this.topK = 40,
    this.gpuLayers = 0,
    this.enableMetal = false,
    this.enableCuda = false,
    this.batchSize = 512,
  });
}

class LlamaInferenceEngine {
  LlamaCppBindings? _bindings;
  Pointer<Void>? _model;
  Pointer<Void>? _context;

  // Optimized settings
  int _threads = 4;
  int _gpuLayers = 0;
  bool _enableMetal = false;
  bool _enableCuda = false;
  int _batchSize = 512;

  // Performance optimization: token batch buffer
  final List<int> _tokenBuffer = [];
  static const int _maxBufferSize = 32;

  Future<void> initialize() async {
    String libPath;
    if (Platform.isIOS) {
      libPath = '@executable_path/Frameworks/libllama.dylib';
    } else if (Platform.isAndroid) {
      libPath = 'libllama.so';
    } else if (Platform.isMacOS) {
      // macOS: try to load from common locations
      final possiblePaths = [
        'libllama.dylib',
        '/usr/local/lib/libllama.dylib',
        '/opt/homebrew/lib/libllama.dylib',
        '${Platform.environment['HOME']}/.local/lib/libllama.dylib',
      ];
      
      for (final path in possiblePaths) {
        try {
          _bindings = LlamaCppBindings(DynamicLibrary.open(path));
          debugPrint('Loaded llama library from: $path');
          return;
        } catch (e) {
          debugPrint('Failed to load from $path: $e');
          continue;
        }
      }
      throw UnsupportedError(
        'Could not load libllama.dylib on macOS. Please install llama.cpp and ensure the library is available in one of these locations: ${possiblePaths.join(", ")}'
      );
    } else {
      throw UnsupportedError('Unsupported platform: ${Platform.operatingSystem}');
    }

    _bindings = LlamaCppBindings(DynamicLibrary.open(libPath));
  }

  /// Configure optimal settings for the current platform
  void configure({
    int? threads,
    int? gpuLayers,
    bool? enableMetal,
    bool? enableCuda,
    int? batchSize,
  }) {
    _threads = threads ?? _threads;
    _gpuLayers = gpuLayers ?? _gpuLayers;
    _enableMetal = enableMetal ?? _enableMetal;
    _enableCuda = enableCuda ?? _enableCuda;
    _batchSize = batchSize ?? _batchSize;
  }

  Future<bool> loadModel(LlamaModel config) async {
    if (_bindings == null) await initialize();

    final modelPathPtr = config.modelPath.toNativeUtf8();

    try {
      // Allocate params structure with GPU support
      final params = calloc<Int32>(16); // Extended params structure

      // Set params values
      params[0] = config.contextSize;
      params[1] = config.threads;
      params[2] = 512; // max tokens
      params[3] = config.gpuLayers;      // GPU layers
      params[4] = config.batchSize;      // Batch size
      params[5] = config.enableMetal ? 1 : 0;  // Metal enabled
      params[6] = config.enableCuda ? 1 : 0;   // CUDA enabled

      // Load model
      _model = _bindings!.llama_load_model_from_file(modelPathPtr, params.cast());

      if (_model == nullptr) {
        calloc.free(params);
        return false;
      }

      // Create context
      _context = _bindings!.llama_new_context_with_model(_model!, params.cast());

      calloc.free(params);

      if (_context == nullptr) {
        _bindings!.llama_free_model(_model!);
        _model = null;
        return false;
      }

      return true;
    } finally {
      calloc.free(modelPathPtr);
    }
  }

  Future<String> generate(String prompt, {int maxTokens = 512}) async {
    if (_model == null || _context == null) {
      throw StateError('Model not loaded');
    }

    final result = StringBuffer();

    // Tokenize input
    final textPtr = prompt.toNativeUtf8();
    final tokensPtr = calloc<Int32>(2048);

    try {
      final nTokens = _bindings!.llama_tokenize(
        _model!,
        textPtr,
        prompt.length,
        tokensPtr,
        2048,
        1, // add BOS
      );

      if (nTokens < 0) {
        throw StateError('Tokenization failed');
      }

      // Eval tokens with optimized thread count
      final evalResult = _bindings!.llama_eval(
        _context!,
        tokensPtr,
        nTokens,
        0, // n_past
        _threads, // Use configured thread count
      );

      if (evalResult != 0) {
        throw StateError('Evaluation failed');
      }

      // Generate tokens
      for (int i = 0; i < maxTokens; i++) {
        // Get logits (required for sampling but not used directly)
        _bindings!.llama_get_logits(_context!);

        // Sample next token (simplified)
        final candidatesPtr = calloc<Int32>(1000);
        final nextToken = _bindings!.llama_sample_token(
          _context!,
          candidatesPtr,
          1000,
          0.8, // temp
          0.95, // top_p
          40, // top_k
        );

        calloc.free(candidatesPtr);

        // Check for EOS
        if (nextToken == 2) { // EOS token
          break;
        }

        // Convert token to text
        final bufPtr = calloc<Uint8>(256);
        final len = _bindings!.llama_token_to_str(
          _model!,
          nextToken,
          bufPtr.cast(),
          256,
        );

        if (len > 0) {
          // 将Uint8数组转换为字符串
          final bytes = bufPtr.asTypedList(len);
          final tokenStr = String.fromCharCodes(bytes);
          result.write(tokenStr);
        }

        calloc.free(bufPtr);

        // Eval this token for next iteration
        final singleTokenPtr = calloc<Int32>();
        singleTokenPtr.value = nextToken;

        _bindings!.llama_eval(
          _context!,
          singleTokenPtr,
          1,
          nTokens + i,
          4,
        );

        calloc.free(singleTokenPtr);
      }
    } finally {
      calloc.free(textPtr);
      calloc.free(tokensPtr);
    }

    return result.toString();
  }

  Stream<String> generateStream(String prompt, {int maxTokens = 512}) async* {
    if (_model == null || _context == null) {
      throw StateError('Model not loaded');
    }

    // Tokenize input
    final textPtr = prompt.toNativeUtf8();
    final tokensPtr = calloc<Int32>(2048);

    try {
      final nTokens = _bindings!.llama_tokenize(
        _model!,
        textPtr,
        prompt.length,
        tokensPtr,
        2048,
        1, // add BOS
      );

      if (nTokens < 0) {
        throw StateError('Tokenization failed');
      }

      // Eval tokens with optimized thread count
      final evalResult = _bindings!.llama_eval(
        _context!,
        tokensPtr,
        nTokens,
        0, // n_past
        _threads, // Use configured thread count
      );

      if (evalResult != 0) {
        throw StateError('Evaluation failed');
      }

      // Generate tokens streamingly
      for (int i = 0; i < maxTokens; i++) {
        // Get logits (required for sampling but not used directly)
        _bindings!.llama_get_logits(_context!);

        // Sample next token
        final candidatesPtr = calloc<Int32>(1000);
        final nextToken = _bindings!.llama_sample_token(
          _context!,
          candidatesPtr,
          1000,
          0.8, // temp
          0.95, // top_p
          40, // top_k
        );

        calloc.free(candidatesPtr);

        // Check for EOS
        if (nextToken == 2) { // EOS token
          break;
        }

        // Convert token to text
        final bufPtr = calloc<Uint8>(256);
        final len = _bindings!.llama_token_to_str(
          _model!,
          nextToken,
          bufPtr.cast(),
          256,
        );

        if (len > 0) {
          // 将Uint8数组转换为字符串
          final bytes = bufPtr.asTypedList(len);
          final tokenStr = String.fromCharCodes(bytes);
          yield tokenStr; // Yield each token as it's generated
        }

        calloc.free(bufPtr);

        // Eval this token for next iteration
        final singleTokenPtr = calloc<Int32>();
        singleTokenPtr.value = nextToken;

        _bindings!.llama_eval(
          _context!,
          singleTokenPtr,
          1,
          nTokens + i,
          4,
        );

        calloc.free(singleTokenPtr);
      }
    } finally {
      calloc.free(textPtr);
      calloc.free(tokensPtr);
    }
  }

  void dispose() {
    if (_context != null) {
      _bindings!.llama_free(_context!);
      _context = null;
    }
    if (_model != null) {
      _bindings!.llama_free_model(_model!);
      _model = null;
    }
  }
}
