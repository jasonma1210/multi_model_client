import 'dart:io';
import 'package:drift/drift.dart';
import 'package:path/path.dart' as p;
import '../storage/database.dart';
import '../storage/database_connection.dart';
import 'file_parser_service.dart';
import 'chinese_segmenter_service.dart';
import 'bm25_service.dart';

/// 知识库服务 - 管理知识库的 CRUD 和全文检索
class KnowledgeBaseService {
  final AppDatabase _db;

  KnowledgeBaseService(this._db);

  /// 获取所有知识库
  Future<List<KnowledgeBase>> getAllKnowledgeBases() async {
    return await _db.select(_db.knowledgeBases).get();
  }

  /// 获取知识库详情
  Future<KnowledgeBase?> getKnowledgeBase(String id) async {
    final query = _db.select(_db.knowledgeBases)..where((t) => t.id.equals(id));
    return await query.getSingleOrNull();
  }

  /// 创建知识库
  Future<KnowledgeBase> createKnowledgeBase({
    required String name,
    String? description,
  }) async {
    final now = DateTime.now();
    final id = 'kb_${now.millisecondsSinceEpoch}';
    
    final kb = KnowledgeBasesCompanion.insert(
      id: id,
      name: name,
      description: Value(description),
      documentCount: const Value(0),
      createdAt: now,
      updatedAt: now,
    );
    
    await _db.into(_db.knowledgeBases).insert(kb);
    
    // 创建 FTS5 虚拟表用于全文检索
    await _createFtsTable(id);
    
    return (await getKnowledgeBase(id))!;
  }

  /// 更新知识库
  Future<void> updateKnowledgeBase({
    required String id,
    String? name,
    String? description,
  }) async {
    final query = _db.update(_db.knowledgeBases)..where((t) => t.id.equals(id));
    await query.write(
      KnowledgeBasesCompanion(
        name: name != null ? Value(name) : const Value.absent(),
        description: description != null ? Value(description) : const Value.absent(),
        updatedAt: Value(DateTime.now()),
      ),
    );
  }

  /// 删除知识库（同时删除文档和分块）
  Future<void> deleteKnowledgeBase(String id) async {
    // 删除 FTS 表
    await _dropFtsTable(id);
    
    // 删除所有分块
    final chunksQuery = _db.delete(_db.documentChunks)
      ..where((t) => t.knowledgeBaseId.equals(id));
    await chunksQuery.go();
    
    // 删除所有文档
    final docsQuery = _db.delete(_db.documents)
      ..where((t) => t.knowledgeBaseId.equals(id));
    await docsQuery.go();
    
    // 删除知识库
    final kbQuery = _db.delete(_db.knowledgeBases)
      ..where((t) => t.id.equals(id));
    await kbQuery.go();
  }

  /// 获取知识库下的所有文档
  Future<List<Document>> getDocuments(String knowledgeBaseId) async {
    final query = _db.select(_db.documents)
      ..where((t) => t.knowledgeBaseId.equals(knowledgeBaseId))
      ..orderBy([(t) => OrderingTerm.desc(t.createdAt)]);
    return await query.get();
  }

  /// 添加文档到知识库
  Future<Document> addDocument({
    required String knowledgeBaseId,
    required String filePath,
  }) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw Exception('文件不存在: $filePath');
    }

    final fileName = p.basename(filePath);
    final fileType = FileParserService.getFileType(filePath);
    final fileSize = await file.length();
    final now = DateTime.now();
    final docId = 'doc_${now.millisecondsSinceEpoch}';

    // 解析文件内容
    String content;
    try {
      content = await FileParserService.parseFile(filePath);
    } catch (e) {
      // 如果解析失败，记录错误
      final doc = DocumentsCompanion.insert(
        id: docId,
        knowledgeBaseId: knowledgeBaseId,
        fileName: fileName,
        filePath: filePath,
        fileType: fileType,
        fileSize: fileSize,
        status: const Value('failed'),
        errorMessage: Value(e.toString()),
        createdAt: now,
        updatedAt: now,
      );
      await _db.into(_db.documents).insert(doc);
      rethrow;
    }

    // 将内容分块
    final chunks = FileParserService.chunkText(content);
    
    // 创建文档记录
    final doc = DocumentsCompanion.insert(
      id: docId,
      knowledgeBaseId: knowledgeBaseId,
      fileName: fileName,
      filePath: filePath,
      fileType: fileType,
      fileSize: fileSize,
      chunkCount: Value(chunks.length),
      status: const Value('completed'),
      createdAt: now,
      updatedAt: now,
    );
    await _db.into(_db.documents).insert(doc);

    // 将分块存入数据库和 FTS
    for (var i = 0; i < chunks.length; i++) {
      final chunkId = 'chunk_${now.millisecondsSinceEpoch}_$i';
      final chunk = DocumentChunksCompanion.insert(
        id: chunkId,
        knowledgeBaseId: knowledgeBaseId,
        documentId: docId,
        content: chunks[i],
        chunkIndex: i,
        createdAt: now,
      );
      await _db.into(_db.documentChunks).insert(chunk);
      
      // 添加到 FTS 索引
      await _addToFtsIndex(knowledgeBaseId, chunkId, chunks[i]);
    }

    // 更新知识库文档数量
    await _updateDocumentCount(knowledgeBaseId);

    return (await _db.select(_db.documents)..where((t) => t.id.equals(docId))).getSingle();
  }

  /// 删除文档
  Future<void> deleteDocument(String documentId) async {
    // 获取文档信息
    final doc = await (_db.select(_db.documents)
      ..where((t) => t.id.equals(documentId))).getSingleOrNull();
    
    if (doc == null) return;
    
    // 删除关联的分块和 FTS
    final chunks = await (_db.select(_db.documentChunks)
      ..where((t) => t.documentId.equals(documentId))).get();
    
    for (final chunk in chunks) {
      await _removeFromFtsIndex(doc.knowledgeBaseId, chunk.id);
    }
    
    // 删除分块
    await (_db.delete(_db.documentChunks)
      ..where((t) => t.documentId.equals(documentId))).go();
    
    // 删除文档
    await (_db.delete(_db.documents)
      ..where((t) => t.id.equals(documentId))).go();
    
    // 更新知识库文档数量
    await _updateDocumentCount(doc.knowledgeBaseId);
  }

  /// 搜索知识库内容（使用 FTS5 + BM25 排序）
  Future<List<SearchResult>> searchKnowledgeBase(
    String knowledgeBaseId,
    String query, {
    int limit = 5,
  }) async {
    if (query.trim().isEmpty) return [];

    // 使用中文分词预处理查询词
    final searchTerms = _preprocessQuery(query);
    if (searchTerms.isEmpty) return [];

    final ftsTableName = 'knowledge_fts_${knowledgeBaseId}';
    
    try {
      // 使用 FTS5 MATCH 查询，获取更多结果用于 BM25 重排
      final searchQuery = searchTerms.map((t) => '$t*').join(' OR ');
      
      final results = await _db.customSelect(
        '''
        SELECT chunk_id, content, rank 
        FROM "$ftsTableName" 
        WHERE "$ftsTableName" MATCH ?
        ORDER BY rank 
        LIMIT ?
        ''',
        variables: [
          Variable.withString(searchQuery),
          Variable.withInt(limit * 3),
        ],
        readsFrom: { _db.documentChunks },
      ).get();

      // 获取所有分块用于 BM25 计算
      final allChunks = await (_db.select(_db.documentChunks)
        ..where((t) => t.knowledgeBaseId.equals(knowledgeBaseId))).get();

      // 构建 BM25 文档列表
      final bm25Docs = allChunks.map((chunk) => BM25Document(
        id: chunk.id.hashCode,
        content: chunk.content,
      )).toList();

      // 使用 BM25 重排
      final bm25Service = BM25Service(documents: bm25Docs);
      final rankedDocs = bm25Service.getRankedDocuments(query);

      // 合并 FTS 结果和 BM25 排序
      final ftsResultIds = results.map((row) => row.read<String>('chunk_id')).toSet();
      final mergedResults = <SearchResult>[];
      final addedIds = <String>{};
      
      // 首先添加 BM25 排序靠前且在 FTS 结果中的
      for (final doc in rankedDocs) {
        final matchingChunk = allChunks.firstWhere(
          (c) => c.content == doc.content,
          orElse: () => allChunks.first,
        );
        
        if (ftsResultIds.contains(matchingChunk.id) && !addedIds.contains(matchingChunk.id)) {
          mergedResults.add(SearchResult(
            chunkId: matchingChunk.id,
            content: matchingChunk.content,
            rank: doc.id.toDouble(),
          ));
          addedIds.add(matchingChunk.id);
          if (mergedResults.length >= limit) break;
        }
      }
      
      // 如果结果不够，补充 FTS 结果
      if (mergedResults.length < limit) {
        for (final row in results) {
          final chunkId = row.read<String>('chunk_id');
          if (!addedIds.contains(chunkId)) {
            mergedResults.add(SearchResult(
              chunkId: chunkId,
              content: row.read<String>('content'),
              rank: row.read<double>('rank'),
            ));
            addedIds.add(chunkId);
            if (mergedResults.length >= limit) break;
          }
        }
      }

      return mergedResults;
    } catch (e) {
      // 如果 FTS 表不存在或出错，回退到 BM25 搜索
      return _bm25Search(knowledgeBaseId, query, limit);
    }
  }

  /// 预处理查询词（使用中文分词）
  List<String> _preprocessQuery(String query) {
    // 使用中文分词器提取关键词
    return ChineseSegmenterService.extractKeywords(query, minLength: 2);
  }

  /// BM25 搜索（回退方案）
  Future<List<SearchResult>> _bm25Search(
    String knowledgeBaseId,
    String query,
    int limit,
  ) async {
    final allChunks = await (_db.select(_db.documentChunks)
      ..where((t) => t.knowledgeBaseId.equals(knowledgeBaseId))).get();
    
    if (allChunks.isEmpty) return [];

    // 构建 BM25 文档
    final bm25Docs = allChunks.map((chunk) => BM25Document(
      id: chunk.id.hashCode,
      content: chunk.content,
    )).toList();

    // 使用 BM25 排序
    final bm25Service = BM25Service(documents: bm25Docs);
    final rankedDocs = bm25Service.getRankedDocuments(query);

    // 映射结果
    final results = <SearchResult>[];
    for (final doc in rankedDocs.take(limit)) {
      final matchingChunk = allChunks.firstWhere(
        (c) => c.content == doc.content,
        orElse: () => allChunks.first,
      );
      results.add(SearchResult(
        chunkId: matchingChunk.id,
        content: matchingChunk.content,
        rank: doc.id.toDouble(),
      ));
    }

    return results;
  }

  /// 更新知识库文档数量
  Future<void> _updateDocumentCount(String knowledgeBaseId) async {
    final count = await (_db.select(_db.documents)
      ..where((t) => t.knowledgeBaseId.equals(knowledgeBaseId))).get();
    
    await (_db.update(_db.knowledgeBases)
      ..where((t) => t.id.equals(knowledgeBaseId))).write(
      KnowledgeBasesCompanion(
        documentCount: Value(count.length),
        updatedAt: Value(DateTime.now()),
      ),
    );
  }

  /// 创建 FTS5 虚拟表
  Future<void> _createFtsTable(String knowledgeBaseId) async {
    final tableName = 'knowledge_fts_${knowledgeBaseId}';
    
    await _db.customStatement(
      '''
      CREATE VIRTUAL TABLE IF NOT EXISTS "$tableName" USING fts5(
        chunk_id,
        content,
        tokenize='unicode61'
      )
      ''',
    );
  }

  /// 删除 FTS5 虚拟表
  Future<void> _dropFtsTable(String knowledgeBaseId) async {
    final tableName = 'knowledge_fts_${knowledgeBaseId}';
    
    await _db.customStatement('DROP TABLE IF EXISTS "$tableName"');
  }

  /// 添加到 FTS 索引
  Future<void> _addToFtsIndex(String knowledgeBaseId, String chunkId, String content) async {
    final tableName = 'knowledge_fts_${knowledgeBaseId}';
    
    await _db.customStatement(
      'INSERT INTO "$tableName" (chunk_id, content) VALUES (?, ?)',
      [chunkId, content],
    );
  }

  /// 从 FTS 索引移除
  Future<void> _removeFromFtsIndex(String knowledgeBaseId, String chunkId) async {
    final tableName = 'knowledge_fts_${knowledgeBaseId}';
    
    await _db.customStatement(
      'DELETE FROM "$tableName" WHERE chunk_id = ?',
      [chunkId],
    );
  }
}

/// 搜索结果
class SearchResult {
  final String chunkId;
  final String content;
  final double rank;

  SearchResult({
    required this.chunkId,
    required this.content,
    required this.rank,
  });
}