import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:archive/archive.dart';

/// 文件解析服务 - 从各种文档格式提取文本内容
class FileParserService {
  /// 解析文件并返回文本内容
  static Future<String> parseFile(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw Exception('文件不存在: $filePath');
    }

    final extension = p.extension(filePath).toLowerCase();
    
    switch (extension) {
      case '.txt':
        return _parseTxt(file);
      case '.md':
      case '.markdown':
        return _parseMarkdown(file);
      case '.pdf':
        return _parsePdf(file);
      case '.ppt':
      case '.pptx':
        return _parsePpt(file);
      case '.doc':
      case '.docx':
        return _parseDoc(file);
      case '.html':
      case '.htm':
        return _parseHtml(file);
      case '.json':
        return _parseJson(file);
      case '.csv':
        return _parseCsv(file);
      default:
        // 尝试作为纯文本处理
        try {
          return await file.readAsString();
        } catch (e) {
          throw Exception('不支持的文件格式: $extension');
        }
    }
  }

  /// 解析 TXT 文件
  static Future<String> _parseTxt(File file) async {
    return await file.readAsString();
  }

  /// 解析 Markdown 文件（简单处理，保留文本内容）
  static Future<String> _parseMarkdown(File file) async {
    final content = await file.readAsString();
    // 简单处理：移除常见 Markdown 语法
    return content
        .replaceAll(RegExp(r'#{1,6}\s+'), '')
        .replaceAll(RegExp(r'\*{1,2}'), '')
        .replaceAll(RegExp(r'_{1,2}'), '')
        .replaceAll(RegExp(r'`{1,3}'), '')
        .replaceAll(RegExp(r'\[([^\]]+)\]\([^)]+\)'), r'$1')
        .replaceAll(RegExp(r'!\[([^\]]*)\]\([^)]+\)'), '')
        .replaceAll(RegExp(r'^\s*[-*+]\s+', multiLine: true), '')
        .replaceAll(RegExp(r'^\s*\d+\.\s+', multiLine: true), '')
        .replaceAll(RegExp(r'^>.*$', multiLine: true), '')
        .replaceAll(RegExp(r'---+\n'), '\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
  }

  /// 解析 PDF 文件（使用 archive 提取文本）
  static Future<String> _parsePdf(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final buffer = StringBuffer();
      
      // PDF 文件结构复杂，这里简单提取所有可见文本
      // 实际生产中建议使用原生平台通道或更专业的 PDF 库
      for (final file in archive.files) {
        if (file.name.endsWith('.xml') && file.name.contains('text')) {
          final xmlContent = String.fromCharCodes(file.content as List<int>);
          // 提取 PDF 文本流
          final textMatches = RegExp(r'\(([^)]+)\)\s*Tj').allMatches(xmlContent);
          for (final match in textMatches) {
            final text = match.group(1);
            if (text != null && text.isNotEmpty) {
              buffer.write(text);
            }
          }
        }
      }
      
      if (buffer.isEmpty) {
        // 如果没有提取到文本，返回提示
        return '【PDF 文件无法直接解析文本】\n\n该 PDF 可能是扫描版或图片版，请转换为文本格式后上传。\n\n或者，您可以使用在线 PDF 转文本工具先将 PDF 转换为 TXT/Markdown 格式。';
      }
      
      return buffer.toString().trim();
    } catch (e) {
      throw Exception('PDF 解析失败: $e\n\n提示: 请将 PDF 转换为 TXT 或 Markdown 格式后上传');
    }
  }

  /// 解析 PPT/PPTX 文件（使用 archive 手动解析）
  static Future<String> _parsePpt(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final buffer = StringBuffer();
      
      // 查找所有 slide XML 文件
      final slides = archive.files
          .where((f) => f.name.startsWith('ppt/slides/slide') && f.name.endsWith('.xml'))
          .toList()
        ..sort((a, b) => a.name.compareTo(b.name));
      
      for (int i = 0; i < slides.length; i++) {
        final slideXml = String.fromCharCodes(slides[i].content as List<int>);
        
        // 简单提取 <a:t> 标签中的文本（PPT 中的文本元素）
        final textMatches = RegExp(r'<a:t>([^<]+)</a:t>').allMatches(slideXml);
        for (final match in textMatches) {
          final text = match.group(1);
          if (text != null && text.isNotEmpty) {
            buffer.writeln(text);
          }
        }
        
        buffer.writeln('\n--- Slide ${i + 1} ---\n');
      }
      
      return buffer.toString().trim();
    } catch (e) {
      throw Exception('PPT 解析失败: $e');
    }
  }

  /// 解析 Word 文件（使用 archive 手动解析）
  static Future<String> _parseDoc(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final buffer = StringBuffer();
      
      // 查找 document.xml 文件
      final docXml = archive.files.firstWhere(
        (f) => f.name == 'word/document.xml',
        orElse: () => throw Exception('Word 文档结构无效'),
      );
      
      final xmlContent = String.fromCharCodes(docXml.content as List<int>);
      
      // 提取所有 <w:t> 标签中的文本
      final textMatches = RegExp(r'<w:t[^>]*>([^<]+)</w:t>').allMatches(xmlContent);
      for (final match in textMatches) {
        final text = match.group(1);
        if (text != null && text.isNotEmpty) {
          buffer.writeln(text);
        }
      }
      
      return buffer.toString().trim();
    } catch (e) {
      throw Exception('Word 解析失败: $e');
    }
  }

  /// 解析 HTML 文件
  static Future<String> _parseHtml(File file) async {
    final content = await file.readAsString();
    // 简单处理：移除 HTML 标签
    return content
        .replaceAll(RegExp(r'<script[^>]*>.*?</script>', caseSensitive: false, dotAll: true), '')
        .replaceAll(RegExp(r'<style[^>]*>.*?</style>', caseSensitive: false, dotAll: true), '')
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  /// 解析 JSON 文件
  static Future<String> _parseJson(File file) async {
    // JSON 作为纯文本返回
    return await file.readAsString();
  }

  /// 解析 CSV 文件
  static Future<String> _parseCsv(File file) async {
    final content = await file.readAsString();
    // CSV 转换为易读的文本格式
    final lines = content.split('\n');
    final buffer = StringBuffer();
    
    for (var i = 0; i < lines.length && i < 100; i++) {
      if (lines[i].trim().isNotEmpty) {
        buffer.writeln(lines[i].replaceAll(',', ' | '));
      }
    }
    
    return buffer.toString();
  }

  /// 获取文件类型
  static String getFileType(String filePath) {
    final extension = p.extension(filePath).toLowerCase();
    switch (extension) {
      case '.txt':
        return 'txt';
      case '.md':
      case '.markdown':
        return 'md';
      case '.pdf':
        return 'pdf';
      case '.ppt':
      case '.pptx':
        return 'ppt';
      case '.doc':
      case '.docx':
        return 'doc';
      case '.html':
      case '.htm':
        return 'html';
      case '.json':
        return 'json';
      case '.csv':
        return 'csv';
      default:
        return 'unknown';
    }
  }

  /// 检查文件类型是否支持
  static bool isSupported(String filePath) {
    final extension = p.extension(filePath).toLowerCase();
    return ['.txt', '.md', '.markdown', '.pdf', '.ppt', '.pptx', '.doc', '.docx', '.html', '.htm', '.json', '.csv'].contains(extension);
  }

  /// 将文本分块
  static List<String> chunkText(String text, {int maxChunkSize = 500, int overlap = 50}) {
    if (text.isEmpty) return [];

    final chunks = <String>[];
    final paragraphs = text.split(RegExp(r'\n{2,}'));
    
    String currentChunk = '';
    
    for (final paragraph in paragraphs) {
      final trimmed = paragraph.trim();
      if (trimmed.isEmpty) continue;
      
      // 如果单个段落超过最大长度，需要进一步拆分
      if (trimmed.length > maxChunkSize) {
        // 先保存当前累积的内容
        if (currentChunk.isNotEmpty) {
          chunks.add(currentChunk.trim());
          currentChunk = '';
        }
        
        // 将长段落按句子拆分
        final sentences = trimmed.split(RegExp(r'(?<=[。！？.!?])\s*'));
        String tempChunk = '';
        
        for (final sentence in sentences) {
          if ((tempChunk + sentence).length > maxChunkSize) {
            if (tempChunk.isNotEmpty) {
              chunks.add(tempChunk.trim());
              // 保留最后 overlap 个字符作为下一个块的开头
              tempChunk = tempChunk.length > overlap 
                  ? tempChunk.substring(tempChunk.length - overlap) 
                  : tempChunk;
            }
            tempChunk = sentence;
          } else {
            tempChunk += sentence;
          }
        }
        
        currentChunk = tempChunk;
      } else if ((currentChunk + '\n\n' + trimmed).length > maxChunkSize) {
        // 当前块已满，保存并开始新块
        if (currentChunk.isNotEmpty) {
          chunks.add(currentChunk.trim());
          // 保留最后 overlap 个字符
          currentChunk = currentChunk.length > overlap 
              ? currentChunk.substring(currentChunk.length - overlap) 
              : currentChunk;
        }
        currentChunk = trimmed;
      } else {
        // 追加到当前块
        if (currentChunk.isEmpty) {
          currentChunk = trimmed;
        } else {
          currentChunk += '\n\n' + trimmed;
        }
      }
    }
    
    // 添加最后一个块
    if (currentChunk.isNotEmpty) {
      chunks.add(currentChunk.trim());
    }
    
    return chunks;
  }
}