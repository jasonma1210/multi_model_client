/// 中文分词服务
/// 使用简单分词 + n-gram 方案，支持中英文
class ChineseSegmenterService {
  static bool _initialized = false;

  /// 初始化分词器
  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
  }

  /// 对文本进行分词
  /// 返回分词后的词列表
  static List<String> segment(String text) {
    return _simpleSegment(text);
  }

  /// 简单分词方案
  /// 按标点和空格分词 + n-gram 生成
  static List<String> _simpleSegment(String text) {
    final words = <String>[];
    
    // 清理文本，保留中文、英文、数字
    final cleaned = text.replaceAll(RegExp(r'[^\w\s\u4e00-\u9fff]'), ' ');
    
    // 按空白字符分割
    final tokens = cleaned.split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    
    // 添加原始词
    words.addAll(tokens);
    
    // 生成 2-gram（对于中文特别有用）
    for (int i = 0; i < tokens.length - 1; i++) {
      final t1 = tokens[i];
      final t2 = tokens[i + 1];
      
      // 如果两个都是中文字符，生成 2-gram
      if (_isChinese(t1) && _isChinese(t2)) {
        words.add(t1 + t2);
      }
      // 如果都是英文字符，生成组合词
      else if (_isEnglish(t1) && _isEnglish(t2)) {
        words.add(t1.toLowerCase() + '_' + t2.toLowerCase());
      }
    }
    
    return words;
  }

  /// 判断是否为中文字符
  static bool _isChinese(String text) {
    if (text.isEmpty) return false;
    final char = text.codeUnitAt(0);
    return char >= 0x4E00 && char <= 0x9FFF;
  }

  /// 判断是否为英文字符
  static bool _isEnglish(String text) {
    if (text.isEmpty) return false;
    return RegExp(r'^[a-zA-Z]+$').hasMatch(text);
  }

  /// 将文本转换为查询词列表
  /// 提取关键词（过滤停用词和短词）
  static List<String> extractKeywords(String text, {int minLength = 2}) {
    final words = segment(text);
    
    // 过滤停用词和短词
    final stopWords = {
      '的', '了', '在', '是', '我', '有', '和', '就', '不', '人',
      '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去',
      '你', '会', '着', '没有', '看', '好', '自己', '这', '那',
      'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
      'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
      'would', 'could', 'should', 'may', 'might', 'must', 'can',
    };
    
    return words
        .where((w) => w.length >= minLength && !stopWords.contains(w.toLowerCase()))
        .toList();
  }
}