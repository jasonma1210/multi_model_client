import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:go_router/go_router.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/locale_provider.dart';
import '../../../../core/providers/settings_provider.dart';
import '../../../../core/services/backup_service.dart';
import '../../../../l10n/app_localizations.dart';

// 备份服务 Provider
final backupServiceProvider = Provider<BackupService>((ref) {
  return BackupService();
});

class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});

  @override
  ConsumerState<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends ConsumerState<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);
    final locale = ref.watch(localeProvider);
    final theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/'),
        ),
        title: Text(
          l10n.settings,
          style: theme.textTheme.headlineMedium,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppTheme.spacingM),
        children: [
          // Appearance Section
          _SettingsSection(
            title: l10n.appearance,
            children: [
              _SettingsTile(
                icon: Icons.palette_outlined,
                title: l10n.theme,
                subtitle: _getThemeName(themeMode, l10n),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showThemeDialog(context, ref, l10n),
              ),
              _SettingsTile(
                icon: Icons.language,
                title: l10n.language,
                subtitle: getLanguageName(locale),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showLanguageDialog(context, ref, l10n),
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingM),

          // Models Section
          _SettingsSection(
            title: l10n.models,
            children: [
              _SettingsTile(
                icon: Icons.smart_toy_outlined,
                title: l10n.modelManagement,
                subtitle: l10n.configureModels,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/models'),
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingM),

          // AI Features Section
          _SettingsSection(
            title: 'AI Features',
            children: [
              _SettingsTile(
                icon: Icons.psychology_outlined,
                title: l10n.memorySettings,
                subtitle: l10n.configureMemory,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/memory'),
              ),
              _SettingsTile(
                icon: Icons.library_books_outlined,
                title: l10n.knowledgeBase,
                subtitle: l10n.manageKnowledgeBases,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/knowledge'),
              ),
              _SettingsTile(
                icon: Icons.record_voice_over_outlined,
                title: l10n.voiceSettings,
                subtitle: l10n.textToSpeechConfig,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/voice'),
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingM),

          // Skills Section
          _SettingsSection(
            title: 'Skills',
            children: [
              _SettingsTile(
                icon: Icons.extension_outlined,
                title: '技能中心',
                subtitle: '浏览、管理和创建自定义技能',
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/skills'),
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingM),

          // Data Section
          _SettingsSection(
            title: l10n.dataStorage,
            children: [
              _SettingsTile(
                icon: Icons.storage_outlined,
                title: l10n.storage,
                subtitle: l10n.manageDataCache,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showStorageInfo(context, l10n),
              ),
              _SettingsTile(
                icon: Icons.folder_outlined,
                title: '存储位置配置',
                subtitle: '自定义模型、知识库、备份等文件存储位置',
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/settings/storage'),
              ),
              _SettingsTile(
                icon: Icons.backup_outlined,
                title: l10n.backupExport,
                subtitle: l10n.exportBackupData,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showBackupOptions(context, l10n),
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingM),

          // About Section
          _SettingsSection(
            title: l10n.about,
            children: [
              _SettingsTile(
                icon: Icons.info_outline,
                title: l10n.version,
                subtitle: '1.0.0',
                trailing: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppTheme.spacingS,
                    vertical: AppTheme.spacingXS,
                  ),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusS),
                  ),
                  child: Text(
                    l10n.latest,
                    style: TextStyle(
                      color: theme.colorScheme.primary,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              _SettingsTile(
                icon: Icons.code_outlined,
                title: l10n.openSourceLicenses,
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  showLicensePage(
                    context: context,
                    applicationName: l10n.appTitle,
                    applicationVersion: '1.0.0',
                    applicationIcon: Container(
                      padding: const EdgeInsets.all(AppTheme.spacingM),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary,
                        borderRadius: BorderRadius.circular(AppTheme.radiusM),
                      ),
                      child: const Icon(
                        Icons.smart_toy,
                        color: Colors.white,
                        size: 48,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),

          const SizedBox(height: AppTheme.spacingXXL),
        ],
      ),
    );
  }

  String _getThemeName(ThemeMode mode, AppLocalizations l10n) {
    switch (mode) {
      case ThemeMode.light:
        return l10n.light;
      case ThemeMode.dark:
        return l10n.dark;
      case ThemeMode.system:
        return l10n.system;
    }
  }

  void _showThemeDialog(BuildContext context, WidgetRef ref, AppLocalizations l10n) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.chooseTheme),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusM),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _ThemeOption(
              title: l10n.light,
              icon: Icons.light_mode,
              isSelected: ref.read(themeProvider) == ThemeMode.light,
              onTap: () {
                ref.read(themeProvider.notifier).setTheme(ThemeMode.light);
                Navigator.pop(context);
              },
            ),
            _ThemeOption(
              title: l10n.dark,
              icon: Icons.dark_mode,
              isSelected: ref.read(themeProvider) == ThemeMode.dark,
              onTap: () {
                ref.read(themeProvider.notifier).setTheme(ThemeMode.dark);
                Navigator.pop(context);
              },
            ),
            _ThemeOption(
              title: l10n.system,
              icon: Icons.settings_suggest,
              isSelected: ref.read(themeProvider) == ThemeMode.system,
              onTap: () {
                ref.read(themeProvider.notifier).setTheme(ThemeMode.system);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showLanguageDialog(BuildContext context, WidgetRef ref, AppLocalizations l10n) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.chooseLanguage),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusM),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _LanguageOption(
              title: 'English',
              subtitle: 'English',
              isSelected: ref.read(localeProvider).languageCode == 'en',
              onTap: () {
                ref.read(localeProvider.notifier).setLocale(const Locale('en', 'US'));
                Navigator.pop(context);
              },
            ),
            _LanguageOption(
              title: '中文',
              subtitle: 'Chinese',
              isSelected: ref.read(localeProvider).languageCode == 'zh',
              onTap: () {
                ref.read(localeProvider.notifier).setLocale(const Locale('zh', 'CN'));
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context, AppLocalizations l10n) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.info_outline, color: Colors.white),
            const SizedBox(width: AppTheme.spacingS),
            Text(l10n.comingSoon),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusS),
        ),
      ),
    );
  }

  void _showStorageInfo(BuildContext context, AppLocalizations l10n) async {
    final appDir = await getApplicationDocumentsDirectory();
    final cacheDir = await getTemporaryDirectory();

    int dbSize = 0;
    int cacheSize = 0;
    int modelsSize = 0;

    // Calculate database size
    final dbFile = File('${appDir.path}/app_database.sqlite');
    if (await dbFile.exists()) {
      dbSize = await dbFile.length();
    }

    // Calculate cache size
    if (await cacheDir.exists()) {
      cacheSize = await _calculateDirectorySize(cacheDir);
    }

    // Calculate models size
    final modelsDir = Directory('${appDir.path}/models');
    if (await modelsDir.exists()) {
      modelsSize = await _calculateDirectorySize(modelsDir);
    }

    if (!context.mounted) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.storageInfo),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusM),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _StorageItem(
              icon: Icons.storage,
              label: l10n.database,
              size: dbSize,
            ),
            const SizedBox(height: AppTheme.spacingS),
            _StorageItem(
              icon: Icons.cached,
              label: l10n.cache,
              size: cacheSize,
            ),
            const SizedBox(height: AppTheme.spacingS),
            _StorageItem(
              icon: Icons.smart_toy,
              label: l10n.models,
              size: modelsSize,
            ),
            const Divider(height: AppTheme.spacingL),
            _StorageItem(
              icon: Icons.folder,
              label: l10n.total,
              size: dbSize + cacheSize + modelsSize,
              isTotal: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.close),
          ),
          ElevatedButton.icon(
            onPressed: () async {
              Navigator.pop(context);

              try {
                if (await cacheDir.exists()) {
                  await cacheDir.delete(recursive: true);
                  await cacheDir.create();
                }

                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(l10n.cacheCleared),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${l10n.clearCacheFailed}: $e'),
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: Theme.of(context).colorScheme.error,
                    ),
                  );
                }
              }
            },
            icon: const Icon(Icons.delete_outline),
            label: Text(l10n.clearCache),
          ),
        ],
      ),
    );
  }

  Future<int> _calculateDirectorySize(Directory dir) async {
    int size = 0;
    try {
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          size += await entity.length();
        }
      }
    } catch (e) {
      // Ignore errors
    }
    return size;
  }

  void _showBackupOptions(BuildContext context, AppLocalizations l10n) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppTheme.radiusL),
        ),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacingM),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(AppTheme.spacingS),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusS),
                  ),
                  child: Icon(
                    Icons.upload_file,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                title: Text(l10n.exportDatabase),
                subtitle: Text(l10n.exportAllData),
                onTap: () {
                  Navigator.pop(context);
                  _exportDatabase(context, l10n);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(AppTheme.spacingS),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusS),
                  ),
                  child: Icon(
                    Icons.download,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                title: Text(l10n.importDatabase),
                subtitle: Text(l10n.importFromBackup),
                onTap: () {
                  Navigator.pop(context);
                  _importDatabase(context, l10n);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(AppTheme.spacingS),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusS),
                  ),
                  child: Icon(
                    Icons.share,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                title: Text(l10n.exportSessions),
                subtitle: Text(l10n.exportSpecificSessions),
                onTap: () {
                  Navigator.pop(context);
                  _exportSessions(context, l10n);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _exportDatabase(BuildContext context, AppLocalizations l10n) async {
    try {
      final backupService = ref.read(backupServiceProvider);
      
      // 显示加载中
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                SizedBox(width: 16),
                Text('正在导出数据...'),
              ],
            ),
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 30),
          ),
        );
      }

      final filePath = await backupService.exportAllData();

      if (context.mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        
        // 询问是否分享
        final shouldShare = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('导出成功'),
            content: Text('数据已保存到:\n$filePath'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('关闭'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('分享'),
              ),
            ],
          ),
        );

        if (shouldShare == true) {
          await backupService.shareBackup(filePath);
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('导出失败: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  void _importDatabase(BuildContext context, AppLocalizations l10n) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        dialogTitle: '选择备份文件',
      );

      if (result == null || result.files.isEmpty) return;

      final filePath = result.files.single.path;
      if (filePath == null) return;

      // 选择导入模式
      final importMode = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('导入模式'),
          content: const Text('请选择数据合并方式:'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, 'merge'),
              child: const Text('合并（推荐）'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error,
              ),
              onPressed: () => Navigator.pop(ctx, 'replace'),
              child: const Text('覆盖（危险）'),
            ),
          ],
        ),
      );

      if (importMode == null) return;

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                SizedBox(width: 16),
                Text('正在导入数据...'),
              ],
            ),
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 30),
          ),
        );
      }

      final backupService = ref.read(backupServiceProvider);
      await backupService.importData(filePath, merge: importMode == 'merge');

      if (context.mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('导入成功！'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('导入失败: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  void _exportSessions(BuildContext context, AppLocalizations l10n) {
    // 导出单个会话功能已在会话详情页实现
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('请在会话详情页点击导出按钮'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

// Helper Widgets

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            left: AppTheme.spacingS,
            bottom: AppTheme.spacingS,
          ),
          child: Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(AppTheme.spacingS),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.radiusS),
        ),
        child: Icon(
          icon,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle!) : null,
      trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_right) : null),
      onTap: onTap,
    );
  }
}

class _ThemeOption extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeOption({
    required this.title,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      leading: Icon(
        icon,
        color: isSelected ? theme.colorScheme.primary : null,
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      trailing: isSelected
          ? Icon(
              Icons.check_circle,
              color: theme.colorScheme.primary,
            )
          : null,
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.radiusS),
      ),
    );
  }
}

class _LanguageOption extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isSelected;
  final VoidCallback onTap;

  const _LanguageOption({
    required this.title,
    required this.subtitle,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      leading: Icon(
        Icons.language,
        color: isSelected ? theme.colorScheme.primary : null,
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      subtitle: Text(subtitle),
      trailing: isSelected
          ? Icon(
              Icons.check_circle,
              color: theme.colorScheme.primary,
            )
          : null,
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.radiusS),
      ),
    );
  }
}

class _StorageItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int size;
  final bool isTotal;

  const _StorageItem({
    required this.icon,
    required this.label,
    required this.size,
    this.isTotal = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: isTotal ? theme.colorScheme.primary : null,
        ),
        const SizedBox(width: AppTheme.spacingM),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontWeight: isTotal ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
        Text(
          _formatBytes(size),
          style: TextStyle(
            fontWeight: isTotal ? FontWeight.w600 : FontWeight.normal,
            color: isTotal ? theme.colorScheme.primary : null,
          ),
        ),
      ],
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}
