import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/models/model_entry.dart';
import '../../../../core/providers/model_provider.dart';
import '../../../../core/engines/model_inference_engine.dart';
import '../../../../core/interfaces/model_interface.dart';

/// 使用全局单例
ModelInferenceEngine get _engine => globalModelEngine;

// ════════════════════════════════════════════════════════════════════════════
//  模型加载 & 参数配置页（对照效果图完整实现）
//  路由: /model/:id/load
// ════════════════════════════════════════════════════════════════════════════

class ModelLoadPage extends ConsumerStatefulWidget {
  final String modelId;
  const ModelLoadPage({super.key, required this.modelId});

  @override
  ConsumerState<ModelLoadPage> createState() => _ModelLoadPageState();
}

class _ModelLoadPageState extends ConsumerState<ModelLoadPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  /// 当前正在编辑的参数（副本）
  LocalModelParams _params = const LocalModelParams();

  /// 预设名称控制器
  final _presetNameController = TextEditingController();

  /// 加载方式选择：true = Ollama API, false = llama.cpp FFI
  bool _preferOllama = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    // 读取已保存的参数
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final models = ref.read(modelProvider).models;
      final model = models.where((m) => m.id == widget.modelId).firstOrNull;
      if (model?.localParams != null) {
        setState(() => _params = model!.localParams!);
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _presetNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final modelState = ref.watch(modelProvider);
    final model = modelState.models.where((m) => m.id == widget.modelId).firstOrNull;

    if (model == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('模型不存在')),
        body: const Center(child: Text('找不到指定模型')),
      );
    }

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text(model.displayName),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            if (context.canPop()) {
              context.pop();
            } else {
              context.go('/');
            }
          },
        ),
        actions: [
          // 保存参数
          TextButton.icon(
            onPressed: _saveParams,
            icon: const Icon(Icons.save_outlined, size: 18),
            label: const Text('保存'),
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Model Parameters'),
            Tab(text: '模型信息'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildParamsTab(theme, model),
          _buildInfoTab(theme, model),
        ],
      ),
      // 底部加载/卸载按钮
      bottomNavigationBar: _buildBottomBar(theme, model),
    );
  }

  // ──────────────────────────── 参数面板 ────────────────────────────

  Widget _buildParamsTab(ThemeData theme, ModelEntry model) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // ── 预设区域 ──
        _SectionCard(
          children: [
            Row(
              children: [
                Icon(Icons.tune_rounded, size: 18, color: theme.colorScheme.secondary),
                const SizedBox(width: 8),
                Text('预设', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHigh,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _params.systemPromptPreset,
                        isExpanded: true,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        borderRadius: BorderRadius.circular(10),
                        hint: const Text('选择预设...'),
                        items: const [
                          DropdownMenuItem(value: 'default', child: Text('默认')),
                          DropdownMenuItem(value: 'creative', child: Text('创意写作')),
                          DropdownMenuItem(value: 'precise', child: Text('精确问答')),
                          DropdownMenuItem(value: 'custom', child: Text('自定义')),
                        ],
                        onChanged: (v) => setState(() =>
                            _params = _params.copyWith(systemPromptPreset: v)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // 清除预设
                if (_params.systemPromptPreset != null)
                  IconButton.outlined(
                    icon: const Icon(Icons.close, size: 16),
                    onPressed: () => setState(() =>
                        _params = _params.copyWith(systemPromptPreset: null)),
                    style: IconButton.styleFrom(
                      padding: const EdgeInsets.all(6),
                      minimumSize: const Size(36, 36),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _saveAsPreset,
                icon: const Icon(Icons.bookmark_border, size: 16),
                label: const Text('Save'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── 设置区域 ──
        _CollapsibleSection(
          title: '设置',
          icon: Icons.settings_outlined,
          defaultExpanded: true,
          children: [
            // 温度
            _SliderParam(
              label: '温度',
              value: _params.temperature,
              min: 0.0,
              max: 2.0,
              divisions: 200,
              onChanged: (v) => setState(() => _params = _params.copyWith(temperature: v)),
            ),
            const SizedBox(height: 8),
            // 限制响应长度
            _SwitchParam(
              label: '限制响应长度',
              value: _params.limitResponseLength,
              onChanged: (v) => setState(() => _params = _params.copyWith(limitResponseLength: v)),
            ),
            const SizedBox(height: 8),
            // 上下文溢出
            _DropdownParam(
              label: '上下文溢出',
              value: _params.contextOverflow,
              items: const {
                'truncate_middle': '截断中间',
                'truncate_start': '截断开头',
                'truncate_end': '截断末尾',
              },
              onChanged: (v) => setState(() => _params = _params.copyWith(contextOverflow: v!)),
            ),
            const SizedBox(height: 8),
            // 停止字符串
            _TextInputParam(
              label: '停止字符串',
              hint: '输入一个字符串并按 ↵',
              value: _params.stopString,
              onChanged: (v) => setState(() => _params = _params.copyWith(
                  stopString: v.isEmpty ? null : v)),
            ),
            const SizedBox(height: 8),
            // CPU 线程数
            _StepperParam(
              label: 'CPU 线程',
              value: _params.cpuThreads,
              min: 1,
              max: 32,
              onChanged: (v) => setState(() => _params = _params.copyWith(cpuThreads: v)),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── 采样区域 ──
        _CollapsibleSection(
          title: '采样',
          icon: Icons.auto_fix_high_outlined,
          defaultExpanded: true,
          children: [
            // Top K
            _StepperParam(
              label: 'Top K 采样',
              value: _params.topK,
              min: 1,
              max: 200,
              onChanged: (v) => setState(() => _params = _params.copyWith(topK: v)),
            ),
            const SizedBox(height: 8),
            // 重复惩罚
            _SwitchSliderParam(
              label: '重复惩罚',
              enabled: _params.repeatPenaltyEnabled,
              value: _params.repeatPenalty,
              min: 1.0,
              max: 2.0,
              divisions: 100,
              onEnabledChanged: (v) => setState(
                  () => _params = _params.copyWith(repeatPenaltyEnabled: v)),
              onValueChanged: (v) =>
                  setState(() => _params = _params.copyWith(repeatPenalty: v)),
            ),
            const SizedBox(height: 8),
            // 存在惩罚
            _SwitchParam(
              label: '存在惩罚',
              value: _params.presencePenaltyEnabled,
              onChanged: (v) => setState(
                  () => _params = _params.copyWith(presencePenaltyEnabled: v)),
            ),
            const SizedBox(height: 8),
            // Top P
            _SwitchSliderParam(
              label: 'Top P 采样',
              enabled: _params.topPEnabled,
              value: _params.topP,
              min: 0.0,
              max: 1.0,
              divisions: 100,
              onEnabledChanged: (v) =>
                  setState(() => _params = _params.copyWith(topPEnabled: v)),
              onValueChanged: (v) =>
                  setState(() => _params = _params.copyWith(topP: v)),
            ),
            const SizedBox(height: 8),
            // Min P
            _SwitchSliderParam(
              label: '最小 P 采样',
              enabled: _params.minPEnabled,
              value: _params.minP,
              min: 0.0,
              max: 0.5,
              divisions: 50,
              onEnabledChanged: (v) =>
                  setState(() => _params = _params.copyWith(minPEnabled: v)),
              onValueChanged: (v) =>
                  setState(() => _params = _params.copyWith(minP: v)),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── 结构化输出 ──
        _CollapsibleSection(
          title: '结构化输出',
          icon: Icons.data_object_outlined,
          defaultExpanded: false,
          children: [
            _SwitchParam(
              label: '启用结构化输出（JSON Schema）',
              value: _params.structuredOutput,
              onChanged: (v) => setState(() => _params = _params.copyWith(structuredOutput: v)),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── 投机解码 ──
        _CollapsibleSection(
          title: '投机解码',
          icon: Icons.flash_on_outlined,
          defaultExpanded: false,
          children: [
            _SwitchParam(
              label: '启用投机解码（加速推理）',
              value: _params.speculativeDecoding,
              onChanged: (v) =>
                  setState(() => _params = _params.copyWith(speculativeDecoding: v)),
            ),
          ],
        ),
        const SizedBox(height: 80),
      ],
    );
  }

  // ──────────────────────────── 模型信息 ────────────────────────────

  Widget _buildInfoTab(ThemeData theme, ModelEntry model) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _SectionCard(
          children: [
            _InfoRow(label: '模型名称', value: model.displayName),
            if (model.filePath != null) _InfoRow(label: '文件路径', value: model.filePath!),
            if (model.parameterSize != null)
              _InfoRow(label: '参数量', value: '${model.parameterSize}B'),
            if (model.quantLevel != null)
              _InfoRow(label: '量化级别', value: model.quantLevel!),
            _InfoRow(
              label: '类型',
              value: model.isLocal ? '本地模型（通过 Ollama 推理）' : '远程 API 模型',
            ),
            _InfoRow(label: '加载状态', value: model.isLoaded ? '已就绪' : '未加载'),
            if (model.isLocal) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, size: 18, color: theme.colorScheme.primary),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '本地模型需要 Ollama 服务运行中才能加载和推理。请确保已安装并启动 Ollama。',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (model.isRemote && model.remoteConfig != null) ...[
              _InfoRow(label: '协议', value: model.remoteConfig!.protocol.name.toUpperCase()),
              _InfoRow(label: 'Base URL', value: model.remoteConfig!.baseUrl),
              _InfoRow(label: '模型 ID', value: model.remoteConfig!.modelId),
            ],
          ],
        ),
      ],
    );
  }

  // ──────────────────────────── 底部加载栏 ────────────────────────────

  Widget _buildBottomBar(ThemeData theme, ModelEntry model) {
    final isLoaded = model.isLoaded;
    final isRemote = model.isRemote;

    return Container(
      padding: EdgeInsets.fromLTRB(
        16, 12, 16, MediaQuery.paddingOf(context).bottom + 12,
      ),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.dividerColor, width: 0.5)),
      ),
      child: Row(
        children: [
          if (isRemote) ...[
            // 远程模型：验证连通性后开始对话
            Expanded(
              child: FilledButton.icon(
                onPressed: () async {
                  // 先验证连通性
                  try {
                    await _engine.loadModel(model.id);
                    ref.read(modelProvider.notifier).setModelLoaded(model.id, true);
                    if (context.mounted) context.go('/');
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('连接失败: $e'),
                          backgroundColor: Colors.red,
                        ),
                      );
                    }
                  }
                },
                icon: const Icon(Icons.chat_rounded),
                label: const Text('连接并开始对话'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ] else if (isLoaded) ...[
            // 本地模型已加载：显示卸载按钮
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _unloadModel,
                icon: const Icon(Icons.eject_outlined),
                label: const Text('卸载模型'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton.icon(
                onPressed: () => context.go('/'),
                icon: const Icon(Icons.chat_rounded),
                label: const Text('开始对话'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ] else ...[
            // 本地模型未加载：显示加载方式选择 + 加载按钮
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // 加载方式选择
                  Row(
                    children: [
                      Expanded(
                        child: _LoadModeButton(
                          label: 'Ollama API',
                          icon: Icons.cloud_outlined,
                          isSelected: _preferOllama,
                          onTap: () => setState(() => _preferOllama = true),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _LoadModeButton(
                          label: 'llama.cpp',
                          icon: Icons.terminal,
                          isSelected: !_preferOllama,
                          onTap: () => setState(() => _preferOllama = false),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // 加载按钮
                  FilledButton.icon(
                    onPressed: _loadModel,
                    icon: const Icon(Icons.rocket_launch_outlined),
                    label: Text(_preferOllama ? '通过 Ollama 加载' : '通过 llama.cpp 加载'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ──────────────────────────── 操作 ────────────────────────────

  Future<void> _saveParams() async {
    await ref.read(modelProvider.notifier).updateLocalParams(widget.modelId, _params);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('参数已保存'), behavior: SnackBarBehavior.floating),
      );
    }
  }

  Future<void> _saveAsPreset() async {
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('保存为预设'),
        content: TextField(
          controller: _presetNameController,
          decoration: const InputDecoration(labelText: '预设名称'),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, _presetNameController.text.trim()),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    if (name != null && name.isNotEmpty && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('预设「$name」已保存'), behavior: SnackBarBehavior.floating),
      );
    }
  }

  Future<void> _loadModel() async {
    if (!mounted) return;

    final model = ref
        .read(modelProvider)
        .models
        .where((m) => m.id == widget.modelId)
        .firstOrNull;

    if (model == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('模型不存在'), backgroundColor: Colors.red),
      );
      return;
    }

    // 加载状态监听器
    StreamSubscription<ModelLoadingState>? loadingSub;
    String? lastError;
    bool loadCompleted = false;

    // 显示加载进度对话框
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _ModelLoadingDialog(
        modelName: model.displayName,
        onCompleted: () {
          // 对话框动画完成后关闭
          if (mounted) Navigator.pop(ctx);
        },
      ),
    );

    // 创建超时控制器
    Timer? timeoutController;

    try {
      // 设置60秒超时
      timeoutController = Timer(const Duration(seconds: 60), () {
        if (!loadCompleted) {
          lastError = '模型加载超时（60秒），请检查 Ollama 服务是否正常运行';
          loadCompleted = true;
          loadingSub?.cancel();
          if (mounted) {
            Navigator.of(context, rootNavigator: true).pop();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(lastError!),
                backgroundColor: Colors.red,
                duration: const Duration(seconds: 5),
              ),
            );
          }
        }
      });

      // 监听加载状态
      loadingSub = _engine.loadingStateStream.listen((state) {
        if (state.modelId == widget.modelId) {
          if (state.status == LoadingStatus.error && state.error != null) {
            lastError = state.error;
          }
        }
      });

      // 用全局单例加载模型（Ollama 验证连通性 / 远程 API 验证）
      await _engine.loadModel(widget.modelId).timeout(
        const Duration(seconds: 60),
        onTimeout: () {
          throw TimeoutException('模型加载超时，请检查网络连接和 Ollama 服务');
        },
      );

      loadCompleted = true;
      timeoutController?.cancel();
      loadingSub?.cancel();

      // 更新模型状态为已加载
      ref.read(modelProvider.notifier).setModelLoaded(widget.modelId, true);

      // 关闭加载对话框
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${model.displayName} 加载成功，可以开始对话了')),
        );
      }
    } catch (e) {
      debugPrint('模型加载失败: $e');
      timeoutController?.cancel();
      loadingSub?.cancel();

      // 关闭加载对话框
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('模型加载失败: ${lastError ?? e}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  Future<void> _unloadModel() async {
    try {
      // 用全局单例卸载模型
      await _engine.unloadModel(widget.modelId);

      // 更新模型状态
      ref.read(modelProvider.notifier).setModelLoaded(widget.modelId, false);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('模型已卸载'), behavior: SnackBarBehavior.floating),
        );
      }
    } catch (e) {
      debugPrint('模型卸载失败: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('模型卸载失败: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  模型加载进度对话框
// ════════════════════════════════════════════════════════════════════════════

class _ModelLoadingDialog extends StatefulWidget {
  final String modelName;
  final VoidCallback onCompleted;
  final void Function(String state)? onStateChanged;

  const _ModelLoadingDialog({
    required this.modelName,
    required this.onCompleted,
    this.onStateChanged,
  });

  @override
  State<_ModelLoadingDialog> createState() => _ModelLoadingDialogState();
}

class _ModelLoadingDialogState extends State<_ModelLoadingDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _progressController;
  String _currentStep = '正在连接模型服务...';
  double _progress = 0.0;
  bool _isCompleted = false;
  String? _errorMessage;

  static const _steps = [
    (0.1, '正在连接模型服务...'),
    (0.3, '验证模型可用性...'),
    (0.5, '加载模型配置...'),
    (0.7, '初始化推理引擎...'),
    (0.85, '预热推理上下文...'),
    (0.95, '准备就绪...'),
    (1.0, '模型加载完成 ✓'),
  ];

  int _stepIndex = 0;

  @override
  void initState() {
    super.initState();
    _progressController = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..addListener(() {
        // 只有在没有错误且未完成时才更新步骤
        if (!_isCompleted && _errorMessage == null) {
          _updateStep(_progressController.value);
        }
      })
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed && !_isCompleted) {
          _isCompleted = true;
          setState(() {
            _progress = 1.0;
            _currentStep = '模型加载完成 ✓';
          });
          Future.delayed(const Duration(milliseconds: 500), widget.onCompleted);
        }
      })
      ..forward();
  }

  void _updateStep(double progress) {
    for (var i = _steps.length - 1; i >= 0; i--) {
      if (progress >= _steps[i].$1) {
        if (_stepIndex != i) {
          setState(() {
            _stepIndex = i;
            _currentStep = _steps[i].$2;
            _progress = progress;
          });
          widget.onStateChanged?.call(_steps[i].$2);
        } else {
          setState(() => _progress = progress);
        }
        break;
      }
    }
  }

  /// 设置加载完成
  void setCompleted() {
    if (_isCompleted) return;
    _isCompleted = true;
    _progressController.stop();
    setState(() {
      _progress = 1.0;
      _currentStep = '模型加载完成 ✓';
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      widget.onCompleted();
    });
  }

  /// 设置错误状态
  void setError(String message) {
    if (_isCompleted) return;
    _isCompleted = true;
    _progressController.stop();
    setState(() {
      _errorMessage = message;
      _currentStep = '加载失败';
    });
  }

  @override
  void dispose() {
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasError = _errorMessage != null;

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      contentPadding: const EdgeInsets.all(28),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 图标
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: hasError
                  ? theme.colorScheme.errorContainer
                  : theme.colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              hasError ? Icons.error_outline : Icons.memory_rounded,
              size: 36,
              color: hasError ? theme.colorScheme.error : theme.colorScheme.primary,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            hasError ? '加载失败' : '正在加载模型',
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            widget.modelName,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          if (hasError && _errorMessage != null) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.colorScheme.errorContainer.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _errorMessage!,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onErrorContainer,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ] else ...[
            const SizedBox(height: 24),
            // 进度条
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: _progress,
                minHeight: 8,
                backgroundColor: theme.colorScheme.surfaceContainerHigh,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _currentStep,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  '${(_progress * 100).toInt()}%',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // 步骤列表
            ..._steps.asMap().entries.map((entry) {
              final idx = entry.key;
              final step = entry.value;
              final isDone = _progress >= step.$1;
              final isCurrent = idx == _stepIndex;

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 18, height: 18,
                      decoration: BoxDecoration(
                        color: isDone
                            ? theme.colorScheme.primary
                            : theme.colorScheme.surfaceContainerHigh,
                        shape: BoxShape.circle,
                      ),
                      child: isDone
                          ? const Icon(Icons.check, size: 12, color: Colors.white)
                          : isCurrent
                              ? Padding(
                                  padding: const EdgeInsets.all(3),
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: theme.colorScheme.primary,
                                  ),
                                )
                              : null,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      step.$2,
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: isDone ? theme.colorScheme.onSurface : theme.colorScheme.outline,
                        fontWeight: isCurrent ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  通用参数控件
// ════════════════════════════════════════════════════════════════════════════

/// 卡片容器
class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsets? padding;

  const _SectionCard({required this.children, this.padding});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.dividerColor.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }
}

/// 可折叠区域
class _CollapsibleSection extends StatefulWidget {
  final String title;
  final IconData icon;
  final bool defaultExpanded;
  final List<Widget> children;

  const _CollapsibleSection({
    required this.title,
    required this.icon,
    this.defaultExpanded = true,
    required this.children,
  });

  @override
  State<_CollapsibleSection> createState() => _CollapsibleSectionState();
}

class _CollapsibleSectionState extends State<_CollapsibleSection>
    with SingleTickerProviderStateMixin {
  late bool _expanded;
  late AnimationController _controller;
  late Animation<double> _heightFactor;

  @override
  void initState() {
    super.initState();
    _expanded = widget.defaultExpanded;
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
      value: _expanded ? 1.0 : 0.0,
    );
    _heightFactor = _controller.drive(CurveTween(curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() {
      _expanded = !_expanded;
      if (_expanded) {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.dividerColor.withValues(alpha: 0.5)),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: _toggle,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Icon(widget.icon, size: 18, color: theme.colorScheme.secondary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      widget.title,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _expanded ? 0 : -0.25,
                    duration: const Duration(milliseconds: 200),
                    child: Icon(Icons.keyboard_arrow_down_rounded,
                        color: theme.colorScheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),
          ClipRect(
            child: AnimatedBuilder(
              animation: _heightFactor,
              builder: (context, child) => Align(
                heightFactor: _heightFactor.value,
                child: child,
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Divider(height: 1),
                    const SizedBox(height: 12),
                    ...widget.children,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 滑块参数
class _SliderParam extends StatelessWidget {
  final String label;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  const _SliderParam({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          flex: 2,
          child: Text(label, style: theme.textTheme.bodyMedium),
        ),
        Expanded(
          flex: 3,
          child: Slider(
            value: value.clamp(min, max),
            min: min, max: max, divisions: divisions,
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 44,
          child: Text(
            value.toStringAsFixed(2),
            style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }
}

/// 开关参数
class _SwitchParam extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchParam({required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyMedium)),
        Switch.adaptive(value: value, onChanged: onChanged),
      ],
    );
  }
}

/// 开关 + 滑块联动参数
class _SwitchSliderParam extends StatelessWidget {
  final String label;
  final bool enabled;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<bool> onEnabledChanged;
  final ValueChanged<double> onValueChanged;

  const _SwitchSliderParam({
    required this.label,
    required this.enabled,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onEnabledChanged,
    required this.onValueChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: theme.textTheme.bodyMedium)),
            Switch.adaptive(value: enabled, onChanged: onEnabledChanged),
            SizedBox(
              width: 44,
              child: Text(
                value.toStringAsFixed(2),
                style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                textAlign: TextAlign.end,
              ),
            ),
          ],
        ),
        if (enabled)
          Slider(
            value: value.clamp(min, max),
            min: min, max: max, divisions: divisions,
            onChanged: onValueChanged,
          ),
      ],
    );
  }
}

/// 下拉选择参数
class _DropdownParam extends StatelessWidget {
  final String label;
  final String value;
  final Map<String, String> items;
  final ValueChanged<String?> onChanged;

  const _DropdownParam({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(flex: 2, child: Text(label, style: theme.textTheme.bodyMedium)),
        Expanded(
          flex: 3,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHigh,
              borderRadius: BorderRadius.circular(8),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                isExpanded: true,
                items: items.entries
                    .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: onChanged,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// 文本输入参数
class _TextInputParam extends StatefulWidget {
  final String label;
  final String hint;
  final String? value;
  final ValueChanged<String> onChanged;

  const _TextInputParam({
    required this.label,
    required this.hint,
    required this.value,
    required this.onChanged,
  });

  @override
  State<_TextInputParam> createState() => _TextInputParamState();
}

class _TextInputParamState extends State<_TextInputParam> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.value);
  }

  @override
  void didUpdateWidget(_TextInputParam oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 外部 value 改变时同步更新，但不重置光标
    if (oldWidget.value != widget.value && _controller.text != widget.value) {
      _controller.text = widget.value ?? '';
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(flex: 2, child: Text(widget.label, style: theme.textTheme.bodyMedium)),
        Expanded(
          flex: 3,
          child: TextField(
            decoration: InputDecoration(
              hintText: widget.hint,
              hintStyle: theme.textTheme.bodySmall,
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: theme.dividerColor),
              ),
              isDense: true,
            ),
            controller: _controller,
            onChanged: widget.onChanged,
          ),
        ),
      ],
    );
  }
}

/// 步进参数
class _StepperParam extends StatelessWidget {
  final String label;
  final int value;
  final int min;
  final int max;
  final ValueChanged<int> onChanged;

  const _StepperParam({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(child: Text(label, style: theme.textTheme.bodyMedium)),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.remove, size: 18),
              onPressed: value > min ? () => onChanged(value - 1) : null,
              style: IconButton.styleFrom(minimumSize: const Size(32, 32)),
            ),
            SizedBox(
              width: 40,
              child: Text(
                '$value',
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.add, size: 18),
              onPressed: value < max ? () => onChanged(value + 1) : null,
              style: IconButton.styleFrom(minimumSize: const Size(32, 32)),
            ),
          ],
        ),
      ],
    );
  }
}

/// 信息行
class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(value, style: theme.textTheme.bodySmall)),
        ],
      ),
    );
  }
}

/// 加载方式选择按钮
class _LoadModeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _LoadModeButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: isSelected
          ? theme.colorScheme.primaryContainer
          : theme.colorScheme.surfaceContainerHigh,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 18,
                color: isSelected
                    ? theme.colorScheme.onPrimaryContainer
                    : theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  color: isSelected
                      ? theme.colorScheme.onPrimaryContainer
                      : theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
